#pragma once

#include "registry.h"

namespace king
{

struct Scene
{
    Registry reg;
};

} // namespace king
