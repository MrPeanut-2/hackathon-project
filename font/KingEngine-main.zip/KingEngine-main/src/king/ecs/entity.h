#pragma once

#include <cstdint>

namespace king
{

using Entity = uint32_t;
static constexpr Entity kInvalidEntity = 0;

} // namespace king
